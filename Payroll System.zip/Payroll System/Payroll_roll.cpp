#include <iostream>
 
using namespace std;
int main( ) {
	
	int default_workingHours=20;
	string employee;
	int attendance,deduction,absence,choice;
	float salary,benefit;
	
		cout << "Are you an employer or an employee?" << endl;
		cout << "1. Employer" << endl;	
		cout << "2. Employee" << endl;
		cout << "Enter 1, 2: ";
		cin >> choice;
		if(choice==1){
			salary=default_workingHours*1000;
			benefit=salary*10/100;
			cout <<"Enter your firstname and surname. Do not provide any space ";
			cin >> employee;
			cout <<"Sir/Madam "<<employee<<" your salary is "<<"$"<<salary<<" with benefit of "<<"$"<<benefit<<"."<<" Your disposable income is "<<"$"<<salary+benefit<<"."<<endl;
			cout << "Thank you.";
		}
		else if(choice==2){
		
		cout << "Enter your firstname and surname. Do not provide any space. ";
		cin >> employee;
		cout << "Enter the number of hours you were present at work out of the 20 working hours ";
		cin >> attendance;
		if(attendance==default_workingHours){
			salary=attendance*160.00;
			benefit=salary*10/100;
			cout <<employee << " was punctual for the month hence there would be no deduction. "<< "Your salary is "<< "$"<< salary << ", since you did not absent yourself from work you have been awarded a 10% benefit on your salary of "<<"$"<< benefit<<endl;
			cout << "Disposable income is "<<"$"<< salary+benefit<<"."<< " Thank you.";
			
		}
		else if(attendance<default_workingHours){
			absence=default_workingHours-attendance;
			salary=attendance*160.00;
			deduction=absence*160.00;
			cout <<employee << " was absent for "<<absence<< " number of hours hence an amount of "<<"$"<<deduction<< " will be deducted from your monthly salary"<<endl;
			cout <<"Your salary is "<<"$"<<salary<<"."<< " You are not eligible for the 10% benefit."<<" Thank you.";
		}
		else{
			cout << "Invalid input";
		}
		
		}
		else{
			cout <<"Wrong input";
		}
		return 0;

		}
	

